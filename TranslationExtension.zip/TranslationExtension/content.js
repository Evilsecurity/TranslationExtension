// Check if the floating window already exists to avoid duplicates
if (!document.getElementById('translatorFloatingWindow')) {
    // Create the floating window
    const translatorDiv = document.createElement('div');
    translatorDiv.id = 'translatorFloatingWindow';
    translatorDiv.innerHTML = `
        <div id="translatorHeader">Translate</div>
        <textarea id="inputText" placeholder="Enter text to translate"></textarea>
        <select id="languageSelect">
            <option value="en">English to Arabic</option>
            <option value="ar">Arabic to English</option>
        </select>
        <button id="translateBtn">Translate</button>
        <textarea id="outputText" placeholder="Translation will appear here" readonly></textarea>
    `;
    
    // Add the floating window to the document body
    document.body.appendChild(translatorDiv);

    // Make the floating window draggable
    dragElement(document.getElementById("translatorFloatingWindow"));

    function dragElement(elmnt) {
        let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
        const header = document.getElementById("translatorHeader");
        
        if (header) {
            header.onmousedown = dragMouseDown;
        }

        function dragMouseDown(e) {
            e.preventDefault();
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e.preventDefault();
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
            elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }

    // Handle translation logic
    document.getElementById('translateBtn').addEventListener('click', () => {
        const inputText = document.getElementById('inputText').value;
        const language = document.getElementById('languageSelect').value;
        let sourceLang = 'en';
        let targetLang = 'ar';

        if (language === 'ar') {
            sourceLang = 'ar';
            targetLang = 'en';
        }

        const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLang}&tl=${targetLang}&dt=t&q=${encodeURIComponent(inputText)}`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                const translatedText = data[0][0][0];
                document.getElementById('outputText').value = translatedText;
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('outputText').value = 'Error in translation';
            });
    });
}
