document.addEventListener('DOMContentLoaded', function() {
    const translateBtn = document.getElementById('translateBtn');
    const inputText = document.getElementById('inputText');
    const outputText = document.getElementById('outputText');
    const languageSelector = document.getElementById('languageSelector');
    const copyBtn = document.getElementById('copyBtn');
    const pasteBtn = document.getElementById('pasteBtn');

    // زر الترجمة
    translateBtn.addEventListener('click', function() {
        const text = inputText.value;
        const langOption = languageSelector.value;

        if (text.trim() === "") {
            outputText.value = "Please enter text.";
            return;
        }

        // استخدام MyMemory API للترجمة
        const apiUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${langOption === 'ar-en' ? 'ar|en' : 'en|ar'}`;

        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                outputText.value = data.responseData.translatedText;
            })
            .catch(error => {
                outputText.value = "Error in translation.";
            });
    });

    // زر النسخ
    copyBtn.addEventListener('click', function() {
        outputText.select();
        document.execCommand('copy');
        alert('Translation copied to clipboard!');
    });

    // زر اللصق
    pasteBtn.addEventListener('click', function() {
        navigator.clipboard.readText()
            .then(text => {
                inputText.value = text;
            })
            .catch(err => {
                alert('Failed to read clipboard contents.');
            });
    });
});
