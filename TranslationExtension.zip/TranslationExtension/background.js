chrome.runtime.onInstalled.addListener(() => {
    console.log("Translator Extension Installed");
});
